import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // dashboardysP (1:259)
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfff6f6f6),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            Container(
              // autogrouppdbfRN1 (UDcuBZr7xcbJrzafEmPdBF)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 25*fem),
              padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 35*fem),
              width: 474*fem,
              decoration: BoxDecoration (
                color: Color(0xff50c2c9),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupzuhfry7 (UDcuRJxDnL6wm7YzZYZUhf)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 25.33*fem, 0*fem),
                    width: 448.67*fem,
                    height: 342*fem,
                    child: Stack(
                      children: [
                        Positioned(
                          // shapeMQ5 (1:260)
                          left: 0*fem,
                          top: 0*fem,
                          child: Align(
                            child: SizedBox(
                              width: 290*fem,
                              height: 270*fem,
                              child: Image.asset(
                                'assets/page-1/images/shape.png',
                                width: 290*fem,
                                height: 270*fem,
                              ),
                            ),
                          ),
                        ),
                        Positioned(
                          // notificationh6Z (1:261)
                          left: 25*fem,
                          top: 15*fem,
                          child: Container(
                            width: 324.67*fem,
                            height: 16*fem,
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  // bxd (I1:261;1:9)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 238.55*fem, 0*fem),
                                  child: Text(
                                    '9:45',
                                    style: SafeGoogleFont (
                                      'Poppins',
                                      fontSize: 13*ffem,
                                      fontWeight: FontWeight.w600,
                                      height: 1.1568750235*ffem/fem,
                                      letterSpacing: 0.78*fem,
                                      color: Color(0xff000000),
                                    ),
                                  ),
                                ),
                                Container(
                                  // signal5cu (I1:261;1:3)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.88*fem, 0*fem),
                                  width: 13.57*fem,
                                  height: 16*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/signal-PHb.png',
                                    width: 13.57*fem,
                                    height: 16*fem,
                                  ),
                                ),
                                Container(
                                  // wifiBR3 (I1:261;1:5)
                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.33*fem, 0*fem),
                                  width: 14.67*fem,
                                  height: 14*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/wifi-vSd.png',
                                    width: 14.67*fem,
                                    height: 14*fem,
                                  ),
                                ),
                                Container(
                                  // batterythreequartersgsb (I1:261;1:7)
                                  width: 14.67*fem,
                                  height: 10*fem,
                                  child: Image.asset(
                                    'assets/page-1/images/battery-three-quarters-8Hf.png',
                                    width: 14.67*fem,
                                    height: 10*fem,
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Positioned(
                          // ellipse11cmF (1:324)
                          left: 141*fem,
                          top: 133*fem,
                          child: Align(
                            child: SizedBox(
                              width: 100*fem,
                              height: 100*fem,
                              child: Container(
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(50*fem),
                                  border: Border.all(color: Color(0xff2b8d93)),
                                  image: DecorationImage (
                                    fit: BoxFit.cover,
                                    image: AssetImage (
                                      'assets/page-1/images/ellipse-11-bg.png',
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // welcomeolivagrace5Pw (1:325)
                    margin: EdgeInsets.fromLTRB(106*fem, 0*fem, 0*fem, 0*fem),
                    child: Text(
                      'Welcome, Oliva Grace',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 18*ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.1568749746*ffem/fem,
                        letterSpacing: 1.08*fem,
                        color: Color(0xffffffff),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // goodafternoonNP3 (1:327)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 24*fem, 0*fem),
              child: Text(
                'Good Afternoon',
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 12*ffem,
                  fontWeight: FontWeight.w600,
                  height: 1.1568749746*ffem/fem,
                  letterSpacing: 0.72*fem,
                  color: Color(0xbf000000),
                ),
              ),
            ),
            Container(
              // autogroupbyrwHF7 (UDcwujoZr2teazfjM3BYRw)
              padding: EdgeInsets.fromLTRB(27*fem, 0*fem, 21*fem, 36*fem),
              width: double.infinity,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  Container(
                    // autogroupzekzC7B (UDcundg2RobheoYWtqZekZ)
                    margin: EdgeInsets.fromLTRB(101*fem, 0*fem, 106*fem, 21*fem),
                    padding: EdgeInsets.fromLTRB(8*fem, 8*fem, 3*fem, 8*fem),
                    width: double.infinity,
                    decoration: BoxDecoration (
                      color: Color(0xfff5efef),
                      borderRadius: BorderRadius.circular(60*fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 2*fem,
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Container(
                          // qR3 (1:329)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 4*fem, 2*fem),
                          child: Text(
                            '12',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 10*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.1568750381*ffem/fem,
                              letterSpacing: 0.6*fem,
                              color: Color(0xff29686c),
                            ),
                          ),
                        ),
                        Container(
                          // autogroupuvchvxH (UDcv1D9QH6VnF9HHHzuvCH)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 6.71*fem),
                          width: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // rqw (1:332)
                                margin: EdgeInsets.fromLTRB(0*fem, 4.71*fem, 22*fem, 0*fem),
                                child: Text(
                                  '9',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 10*ffem,
                                    fontWeight: FontWeight.w600,
                                    height: 1.1568750381*ffem/fem,
                                    letterSpacing: 0.6*fem,
                                    color: Color(0xbf2a696c),
                                  ),
                                ),
                              ),
                              Container(
                                // autogroupyqkfaG9 (UDcv985tEgwdcN5mzgyqKF)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 21.94*fem, 0*fem),
                                width: 51.06*fem,
                                height: 71.29*fem,
                                child: Image.asset(
                                  'assets/page-1/images/auto-group-yqkf.png',
                                  width: 51.06*fem,
                                  height: 71.29*fem,
                                ),
                              ),
                              Container(
                                // Gem (1:331)
                                margin: EdgeInsets.fromLTRB(0*fem, 4.71*fem, 0*fem, 0*fem),
                                child: Text(
                                  '3',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 10*ffem,
                                    fontWeight: FontWeight.w600,
                                    height: 1.1568750381*ffem/fem,
                                    letterSpacing: 0.6*fem,
                                    color: Color(0xbf2a696c),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // yZB (1:330)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 2*fem, 0*fem),
                          child: Text(
                            '6',
                            style: SafeGoogleFont (
                              'Poppins',
                              fontSize: 10*ffem,
                              fontWeight: FontWeight.w600,
                              height: 1.1568750381*ffem/fem,
                              letterSpacing: 0.6*fem,
                              color: Color(0xbf2a696c),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    // taskslistuBw (1:336)
                    margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 229*fem, 20*fem),
                    child: Text(
                      'Tasks List',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 18*ffem,
                        fontWeight: FontWeight.w600,
                        height: 1.1568749746*ffem/fem,
                        letterSpacing: 1.08*fem,
                        color: Color(0xbf000000),
                      ),
                    ),
                  ),
                  Container(
                    // autogroupvdqbCwj (UDcvV2gP4MynR31FdjVDqb)
                    margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 0*fem, 0*fem),
                    padding: EdgeInsets.fromLTRB(21*fem, 24*fem, 26*fem, 20*fem),
                    width: 323*fem,
                    decoration: BoxDecoration (
                      color: Color(0xffffffff),
                      borderRadius: BorderRadius.circular(24*fem),
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x3f000000),
                          offset: Offset(0*fem, 4*fem),
                          blurRadius: 7.5*fem,
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Container(
                          // autogroupf5n1F9K (UDcvimnUt5VRK9yaxWf5N1)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 27*fem),
                          width: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                // taskslistBHs (1:338)
                                margin: EdgeInsets.fromLTRB(0*fem, 1*fem, 183*fem, 0*fem),
                                child: Text(
                                  'Tasks List',
                                  style: SafeGoogleFont (
                                    'Poppins',
                                    fontSize: 14*ffem,
                                    fontWeight: FontWeight.w400,
                                    height: 1.1568750654*ffem/fem,
                                    letterSpacing: 0.84*fem,
                                    color: Color(0xbf000000),
                                  ),
                                ),
                              ),
                              Container(
                                // pluscircletxy (1:354)
                                width: 20*fem,
                                height: 20*fem,
                                child: Image.asset(
                                  'assets/page-1/images/plus-circle.png',
                                  width: 20*fem,
                                  height: 20*fem,
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // group10Ri1 (1:353)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 34*fem, 12*fem),
                          width: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // rectangle29Ynd (1:339)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11*fem, 0*fem),
                                width: 17*fem,
                                height: 17*fem,
                                decoration: BoxDecoration (
                                  border: Border.all(color: Color(0xff000000)),
                                  color: Color(0xff50c2c9),
                                ),
                              ),
                              Text(
                                // cookriceandchickenat10am4FB (1:340)
                                'Cook Rice and Chicken at 10 am',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.1568749746*ffem/fem,
                                  letterSpacing: 0.72*fem,
                                  color: Color(0xbf000000),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // autogroupz1wzP2Z (UDcvq275AVdcp7sZCKZ1WZ)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 8*fem, 18*fem),
                          width: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.end,
                            children: [
                              Container(
                                // autogroupzjxmhow (UDcvwS641q1BVufBHDZjxM)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 52*fem, 0*fem),
                                width: 213*fem,
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Container(
                                      // autogroupffr1q9T (UDcw46ZciYDnxwHH8kFfr1)
                                      padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 18*fem),
                                      width: double.infinity,
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // group9ZLM (1:352)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 36*fem, 18*fem),
                                            width: double.infinity,
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // rectangle3076y (1:342)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11*fem, 0*fem),
                                                  width: 17*fem,
                                                  height: 17*fem,
                                                  decoration: BoxDecoration (
                                                    border: Border.all(color: Color(0xff0f4d51)),
                                                    color: Color(0xffffffff),
                                                  ),
                                                ),
                                                Text(
                                                  // learnreactjsat12pmS9F (1:341)
                                                  'Learn Reactjs at 12 pm',
                                                  style: SafeGoogleFont (
                                                    'Poppins',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.1568749746*ffem/fem,
                                                    letterSpacing: 0.72*fem,
                                                    color: Color(0xbf000000),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                          Container(
                                            // group8ZUm (1:351)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 47*fem, 0*fem),
                                            width: double.infinity,
                                            child: Row(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Container(
                                                  // rectangle31tG9 (1:344)
                                                  margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11*fem, 0*fem),
                                                  width: 17*fem,
                                                  height: 17*fem,
                                                  decoration: BoxDecoration (
                                                    border: Border.all(color: Color(0xff0f4d51)),
                                                    color: Color(0xffffffff),
                                                  ),
                                                ),
                                                Text(
                                                  // havelaunchat1pmRG5 (1:343)
                                                  'Have Launch  at 1pm',
                                                  style: SafeGoogleFont (
                                                    'Poppins',
                                                    fontSize: 12*ffem,
                                                    fontWeight: FontWeight.w400,
                                                    height: 1.1568749746*ffem/fem,
                                                    letterSpacing: 0.72*fem,
                                                    color: Color(0xbf000000),
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                    Container(
                                      // group7Ybb (1:350)
                                      width: double.infinity,
                                      child: Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Container(
                                            // rectangle32hUV (1:346)
                                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11*fem, 0*fem),
                                            width: 17*fem,
                                            height: 17*fem,
                                            decoration: BoxDecoration (
                                              border: Border.all(color: Color(0xff0f4d51)),
                                              color: Color(0xffffffff),
                                            ),
                                          ),
                                          Text(
                                            // learnhtmlandcssat3pmqKo (1:345)
                                            'Learn HTML and CSS at 3pm',
                                            style: SafeGoogleFont (
                                              'Poppins',
                                              fontSize: 12*ffem,
                                              fontWeight: FontWeight.w400,
                                              height: 1.1568749746*ffem/fem,
                                              letterSpacing: 0.72*fem,
                                              color: Color(0xbf000000),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              Container(
                                // rectangle34NKj (1:358)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 3*fem),
                                width: 3*fem,
                                height: 90*fem,
                                decoration: BoxDecoration (
                                  borderRadius: BorderRadius.circular(100*fem),
                                  color: Color(0xffd9d9d9),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          // group6h77 (1:349)
                          margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 115*fem, 0*fem),
                          width: double.infinity,
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Container(
                                // rectangle33Ecq (1:348)
                                margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 11*fem, 0*fem),
                                width: 17*fem,
                                height: 17*fem,
                                decoration: BoxDecoration (
                                  border: Border.all(color: Color(0xff0f4d51)),
                                  color: Color(0xffffffff),
                                ),
                              ),
                              Text(
                                // havedinnerat8pmkbB (1:347)
                                'Have Dinner at 8pm',
                                style: SafeGoogleFont (
                                  'Poppins',
                                  fontSize: 12*ffem,
                                  fontWeight: FontWeight.w400,
                                  height: 1.1568749746*ffem/fem,
                                  letterSpacing: 0.72*fem,
                                  color: Color(0xbf000000),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
          );
  }
}
import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // splashtiM (1:2)
        width: double.infinity,
        height: 812*fem,
        decoration: BoxDecoration (
          color: Color(0xfff6f6f6),
        ),
        child: Stack(
          children: [
            Positioned(
              // shapedA9 (1:63)
              left: 0*fem,
              top: 0*fem,
              child: Align(
                child: SizedBox(
                  width: 290*fem,
                  height: 270*fem,
                  child: Image.asset(
                    'assets/page-1/images/shape-LSM.png',
                    width: 290*fem,
                    height: 270*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // notificationLaM (1:64)
              left: 25*fem,
              top: 15*fem,
              child: Container(
                width: 324.67*fem,
                height: 16*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // rYh (1:9)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 238.55*fem, 0*fem),
                      child: Text(
                        '9:45',
                        style: SafeGoogleFont (
                          'Poppins',
                          fontSize: 13*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.1568750235*ffem/fem,
                          letterSpacing: 0.78*fem,
                          color: Color(0xff000000),
                        ),
                      ),
                    ),
                    Container(
                      // signalke5 (1:3)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.88*fem, 0*fem),
                      width: 13.57*fem,
                      height: 16*fem,
                      child: Image.asset(
                        'assets/page-1/images/signal-FNH.png',
                        width: 13.57*fem,
                        height: 16*fem,
                      ),
                    ),
                    Container(
                      // wifig1w (1:5)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.33*fem, 0*fem),
                      width: 14.67*fem,
                      height: 14*fem,
                      child: Image.asset(
                        'assets/page-1/images/wifi-2x9.png',
                        width: 14.67*fem,
                        height: 14*fem,
                      ),
                    ),
                    Container(
                      // batterythreequarterso6Z (1:7)
                      width: 14.67*fem,
                      height: 10*fem,
                      child: Image.asset(
                        'assets/page-1/images/battery-three-quarters-ucD.png',
                        width: 14.67*fem,
                        height: 10*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // notificationu9b (36:53)
              left: 25*fem,
              top: 15*fem,
              child: Container(
                width: 324.67*fem,
                height: 16*fem,
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Container(
                      // pGZ (I36:53;1:9)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 238.55*fem, 0*fem),
                      child: Text(
                        '9:45',
                        style: SafeGoogleFont (
                          'Poppins',
                          fontSize: 13*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.1568750235*ffem/fem,
                          letterSpacing: 0.78*fem,
                          color: Color(0xff000000),
                        ),
                      ),
                    ),
                    Container(
                      // signalLVo (I36:53;1:3)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.88*fem, 0*fem),
                      width: 13.57*fem,
                      height: 16*fem,
                      child: Image.asset(
                        'assets/page-1/images/signal.png',
                        width: 13.57*fem,
                        height: 16*fem,
                      ),
                    ),
                    Container(
                      // wififHB (I36:53;1:5)
                      margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.33*fem, 0*fem),
                      width: 14.67*fem,
                      height: 14*fem,
                      child: Image.asset(
                        'assets/page-1/images/wifi-VxM.png',
                        width: 14.67*fem,
                        height: 14*fem,
                      ),
                    ),
                    Container(
                      // batterythreequartersaQ9 (I36:53;1:7)
                      width: 14.67*fem,
                      height: 10*fem,
                      child: Image.asset(
                        'assets/page-1/images/battery-three-quarters.png',
                        width: 14.67*fem,
                        height: 10*fem,
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Positioned(
              // undrawmobileuxo0e116dP (1:12)
              left: 102*fem,
              top: 220.0037841797*fem,
              child: Align(
                child: SizedBox(
                  width: 172.55*fem,
                  height: 170*fem,
                  child: Image.asset(
                    'assets/page-1/images/undrawmobileuxo0e1-1.png',
                    width: 172.55*fem,
                    height: 170*fem,
                  ),
                ),
              ),
            ),
            Positioned(
              // getsthingsdonewithtodoxQh (1:48)
              left: 48*fem,
              top: 435*fem,
              child: Align(
                child: SizedBox(
                  width: 283*fem,
                  height: 21*fem,
                  child: Text(
                    'Gets things done with TODO',
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 18*ffem,
                      fontWeight: FontWeight.w600,
                      height: 1.1568749746*ffem/fem,
                      letterSpacing: 1.08*fem,
                      color: Color(0xbf000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // loremipsumdolorsitametconsecte (1:49)
              left: 48*fem,
              top: 492*fem,
              child: Align(
                child: SizedBox(
                  width: 281*fem,
                  height: 72*fem,
                  child: Text(
                    'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Interdum dictum tempus, interdum at dignissim metus. Ultricies sed nunc.',
                    textAlign: TextAlign.center,
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 13*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.3718750293*ffem/fem,
                      letterSpacing: 0.78*fem,
                      color: Color(0xbc000000),
                    ),
                  ),
                ),
              ),
            ),
            Positioned(
              // buttongk1 (1:62)
              left: 26*fem,
              top: 656*fem,
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: 325*fem,
                  height: 62*fem,
                  decoration: BoxDecoration (
                    color: Color(0xff50c2c9),
                  ),
                  child: Center(
                    child: Center(
                      child: Text(
                        'Get Started',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Poppins',
                          fontSize: 18*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.3718750212*ffem/fem,
                          letterSpacing: 1.08*fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}
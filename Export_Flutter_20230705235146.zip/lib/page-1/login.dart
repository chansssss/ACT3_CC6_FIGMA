import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // loginBYd (1:187)
        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 48*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfff6f6f6),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogroupq9tuHbf (UDcyqWvefrWkq3EaFEq9tu)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 25.33*fem, 35*fem),
              width: 448.67*fem,
              height: 270*fem,
              child: Stack(
                children: [
                  Positioned(
                    // shapeopu (1:188)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 290*fem,
                        height: 270*fem,
                        child: Image.asset(
                          'assets/page-1/images/shape-aNu.png',
                          width: 290*fem,
                          height: 270*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // notificationKYM (1:189)
                    left: 25*fem,
                    top: 15*fem,
                    child: Container(
                      width: 324.67*fem,
                      height: 16*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // EvD (I1:189;1:9)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 238.55*fem, 0*fem),
                            child: Text(
                              '9:45',
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 13*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.1568750235*ffem/fem,
                                letterSpacing: 0.78*fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                          Container(
                            // signalLTT (I1:189;1:3)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.88*fem, 0*fem),
                            width: 13.57*fem,
                            height: 16*fem,
                            child: Image.asset(
                              'assets/page-1/images/signal-vvm.png',
                              width: 13.57*fem,
                              height: 16*fem,
                            ),
                          ),
                          Container(
                            // wifirgh (I1:189;1:5)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.33*fem, 0*fem),
                            width: 14.67*fem,
                            height: 14*fem,
                            child: Image.asset(
                              'assets/page-1/images/wifi.png',
                              width: 14.67*fem,
                              height: 14*fem,
                            ),
                          ),
                          Container(
                            // batterythreequartersAxH (I1:189;1:7)
                            width: 14.67*fem,
                            height: 10*fem,
                            child: Image.asset(
                              'assets/page-1/images/battery-three-quarters-r8h.png',
                              width: 14.67*fem,
                              height: 10*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // welcomebackVzZ (1:190)
              margin: EdgeInsets.fromLTRB(2*fem, 0*fem, 0*fem, 35*fem),
              child: Text(
                'Welcome Back!',
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 18*ffem,
                  fontWeight: FontWeight.w600,
                  height: 1.1568749746*ffem/fem,
                  letterSpacing: 1.08*fem,
                  color: Color(0xbf000000),
                ),
              ),
            ),
            Container(
              // undrawmynotificationsrjej1pG9 (1:216)
              margin: EdgeInsets.fromLTRB(0.86*fem, 0*fem, 0*fem, 46*fem),
              width: 171.86*fem,
              height: 170*fem,
              child: Image.asset(
                'assets/page-1/images/undrawmynotificationsrjej-1.png',
                width: 171.86*fem,
                height: 170*fem,
              ),
            ),
            Container(
              // inputXRT (1:193)
              margin: EdgeInsets.fromLTRB(25*fem, 0*fem, 25*fem, 21*fem),
              padding: EdgeInsets.fromLTRB(30*fem, 16*fem, 30*fem, 17*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(22*fem),
              ),
              child: Text(
                'Enter your email',
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 13*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.3718750293*ffem/fem,
                  letterSpacing: 0.78*fem,
                  color: Color(0xb2000000),
                ),
              ),
            ),
            Container(
              // inputzK3 (1:195)
              margin: EdgeInsets.fromLTRB(25*fem, 0*fem, 25*fem, 25*fem),
              padding: EdgeInsets.fromLTRB(30*fem, 16*fem, 30*fem, 17*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(22*fem),
              ),
              child: Text(
                'Enter password',
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 13*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.3718750293*ffem/fem,
                  letterSpacing: 0.78*fem,
                  color: Color(0xb2000000),
                ),
              ),
            ),
            Container(
              // forgotpassword441 (1:256)
              margin: EdgeInsets.fromLTRB(1*fem, 0*fem, 0*fem, 23*fem),
              child: Text(
                'Forgot Password',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 14*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.1568750654*ffem/fem,
                  letterSpacing: 0.84*fem,
                  color: Color(0xff50c2c9),
                ),
              ),
            ),
            Container(
              // button9r9 (1:192)
              margin: EdgeInsets.fromLTRB(25*fem, 0*fem, 25*fem, 29*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: double.infinity,
                  height: 62*fem,
                  decoration: BoxDecoration (
                    color: Color(0xff50c2c9),
                  ),
                  child: Center(
                    child: Center(
                      child: Text(
                        'Sign In',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Poppins',
                          fontSize: 18*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.3718750212*ffem/fem,
                          letterSpacing: 1.08*fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            TextButton(
              // donthaveanaccountsignupzrm (1:257)
              onPressed: () {},
              style: TextButton.styleFrom (
                padding: EdgeInsets.zero,
              ),
              child: RichText(
                textAlign: TextAlign.center,
                text: TextSpan(
                  style: SafeGoogleFont (
                    'Poppins',
                    fontSize: 14*ffem,
                    fontWeight: FontWeight.w400,
                    height: 1.1568750654*ffem/fem,
                    letterSpacing: 0.84*fem,
                    color: Color(0xff000000),
                  ),
                  children: [
                    TextSpan(
                      text: 'Don’t have an account ? ',
                    ),
                    TextSpan(
                      text: 'Sign Up',
                      style: SafeGoogleFont (
                        'Poppins',
                        fontSize: 14*ffem,
                        fontWeight: FontWeight.w700,
                        height: 1.1568750654*ffem/fem,
                        letterSpacing: 0.84*fem,
                        color: Color(0xff50c2c9),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}
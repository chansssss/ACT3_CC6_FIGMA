import 'package:flutter/material.dart';
import 'package:flutter/gestures.dart';
import 'dart:ui';
import 'package:google_fonts/google_fonts.dart';
import 'package:myapp/utils.dart';

class Scene extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    double baseWidth = 375;
    double fem = MediaQuery.of(context).size.width / baseWidth;
    double ffem = fem * 0.97;
    return Container(
      width: double.infinity,
      child: Container(
        // registrationdV3 (1:118)
        padding: EdgeInsets.fromLTRB(0*fem, 0*fem, 0*fem, 54*fem),
        width: double.infinity,
        decoration: BoxDecoration (
          color: Color(0xfff6f6f6),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Container(
              // autogrouptedpvyw (UDczLqR8ZP53gMyRCmTeDP)
              margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 25.33*fem, 76*fem),
              width: 448.67*fem,
              height: 270*fem,
              child: Stack(
                children: [
                  Positioned(
                    // shaperMo (1:119)
                    left: 0*fem,
                    top: 0*fem,
                    child: Align(
                      child: SizedBox(
                        width: 290*fem,
                        height: 270*fem,
                        child: Image.asset(
                          'assets/page-1/images/shape-fEy.png',
                          width: 290*fem,
                          height: 270*fem,
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    // notificationZ1K (1:120)
                    left: 25*fem,
                    top: 15*fem,
                    child: Container(
                      width: 324.67*fem,
                      height: 16*fem,
                      child: Row(
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          Container(
                            // TsP (I1:120;1:9)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 238.55*fem, 0*fem),
                            child: Text(
                              '9:45',
                              style: SafeGoogleFont (
                                'Poppins',
                                fontSize: 13*ffem,
                                fontWeight: FontWeight.w600,
                                height: 1.1568750235*ffem/fem,
                                letterSpacing: 0.78*fem,
                                color: Color(0xff000000),
                              ),
                            ),
                          ),
                          Container(
                            // signalmdB (I1:120;1:3)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.88*fem, 0*fem),
                            width: 13.57*fem,
                            height: 16*fem,
                            child: Image.asset(
                              'assets/page-1/images/signal-bt5.png',
                              width: 13.57*fem,
                              height: 16*fem,
                            ),
                          ),
                          Container(
                            // wifih13 (I1:120;1:5)
                            margin: EdgeInsets.fromLTRB(0*fem, 0*fem, 5.33*fem, 0*fem),
                            width: 14.67*fem,
                            height: 14*fem,
                            child: Image.asset(
                              'assets/page-1/images/wifi-yVK.png',
                              width: 14.67*fem,
                              height: 14*fem,
                            ),
                          ),
                          Container(
                            // batterythreequartersDVB (I1:120;1:7)
                            width: 14.67*fem,
                            height: 10*fem,
                            child: Image.asset(
                              'assets/page-1/images/battery-three-quarters-CcR.png',
                              width: 14.67*fem,
                              height: 10*fem,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Container(
              // welcomeonboard97w (1:157)
              margin: EdgeInsets.fromLTRB(6*fem, 0*fem, 0*fem, 14*fem),
              child: Text(
                'Welcome Onboard!',
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 18*ffem,
                  fontWeight: FontWeight.w600,
                  height: 1.1568749746*ffem/fem,
                  letterSpacing: 1.08*fem,
                  color: Color(0xbf000000),
                ),
              ),
            ),
            Container(
              // letshelpyoumeetupyourtaskseqP (1:158)
              margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 0*fem, 49*fem),
              child: Text(
                'Let’s help you meet up your tasks',
                textAlign: TextAlign.center,
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 13*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.3718750293*ffem/fem,
                  letterSpacing: 0.78*fem,
                  color: Color(0xbc000000),
                ),
              ),
            ),
            Container(
              // input9GM (1:184)
              margin: EdgeInsets.fromLTRB(27*fem, 0*fem, 23*fem, 21*fem),
              padding: EdgeInsets.fromLTRB(30*fem, 16*fem, 30*fem, 17*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(22*fem),
              ),
              child: Text(
                'Enter your full name',
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 13*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.3718750293*ffem/fem,
                  letterSpacing: 0.78*fem,
                  color: Color(0xb2000000),
                ),
              ),
            ),
            Container(
              // inputCVX (1:174)
              margin: EdgeInsets.fromLTRB(27*fem, 0*fem, 23*fem, 21*fem),
              padding: EdgeInsets.fromLTRB(30*fem, 16*fem, 30*fem, 17*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(22*fem),
              ),
              child: Text(
                'Enter your email',
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 13*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.3718750293*ffem/fem,
                  letterSpacing: 0.78*fem,
                  color: Color(0xb2000000),
                ),
              ),
            ),
            Container(
              // inputftu (1:175)
              margin: EdgeInsets.fromLTRB(27*fem, 0*fem, 23*fem, 21*fem),
              padding: EdgeInsets.fromLTRB(30*fem, 16*fem, 30*fem, 17*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(22*fem),
              ),
              child: Text(
                'Enter password',
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 13*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.3718750293*ffem/fem,
                  letterSpacing: 0.78*fem,
                  color: Color(0xb2000000),
                ),
              ),
            ),
            Container(
              // inputMFw (1:181)
              margin: EdgeInsets.fromLTRB(27*fem, 0*fem, 23*fem, 50*fem),
              padding: EdgeInsets.fromLTRB(30*fem, 16*fem, 30*fem, 17*fem),
              width: double.infinity,
              decoration: BoxDecoration (
                color: Color(0xffffffff),
                borderRadius: BorderRadius.circular(22*fem),
              ),
              child: Text(
                'Confirm Password',
                style: SafeGoogleFont (
                  'Poppins',
                  fontSize: 13*ffem,
                  fontWeight: FontWeight.w400,
                  height: 1.3718750293*ffem/fem,
                  letterSpacing: 0.78*fem,
                  color: Color(0xb2000000),
                ),
              ),
            ),
            Container(
              // button38m (1:159)
              margin: EdgeInsets.fromLTRB(27*fem, 0*fem, 23*fem, 23*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: Container(
                  width: double.infinity,
                  height: 62*fem,
                  decoration: BoxDecoration (
                    color: Color(0xff50c2c9),
                  ),
                  child: Center(
                    child: Center(
                      child: Text(
                        'Register',
                        textAlign: TextAlign.center,
                        style: SafeGoogleFont (
                          'Poppins',
                          fontSize: 18*ffem,
                          fontWeight: FontWeight.w600,
                          height: 1.3718750212*ffem/fem,
                          letterSpacing: 1.08*fem,
                          color: Color(0xffffffff),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ),
            Container(
              // alreadyhaveanaccountsignint9P (1:258)
              margin: EdgeInsets.fromLTRB(4*fem, 0*fem, 0*fem, 0*fem),
              child: TextButton(
                onPressed: () {},
                style: TextButton.styleFrom (
                  padding: EdgeInsets.zero,
                ),
                child: RichText(
                  textAlign: TextAlign.center,
                  text: TextSpan(
                    style: SafeGoogleFont (
                      'Poppins',
                      fontSize: 14*ffem,
                      fontWeight: FontWeight.w400,
                      height: 1.1568750654*ffem/fem,
                      letterSpacing: 0.84*fem,
                      color: Color(0xff000000),
                    ),
                    children: [
                      TextSpan(
                        text: 'Already have an account ? ',
                      ),
                      TextSpan(
                        text: 'Sign In',
                        style: SafeGoogleFont (
                          'Poppins',
                          fontSize: 14*ffem,
                          fontWeight: FontWeight.w700,
                          height: 1.1568750654*ffem/fem,
                          letterSpacing: 0.84*fem,
                          color: Color(0xff50c2c9),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
          );
  }
}